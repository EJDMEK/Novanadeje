# GitHub Actions - Nasazení pomocí ZIP souboru

## Jak to funguje

1. **Nahrajte ZIP soubor do GitHub repozitáře**
2. **GitHub Actions automaticky rozbalí a zpracuje soubory**
3. **Buildí frontend a backend**
4. **Připraví soubory pro nasazení**

## Krok za krokem

### 1. Vytvoření ZIP souboru

```powershell
# V adresáři tycko-golf-helper-main
.\create-zip.ps1
```

### 2. Nahrání na GitHub

1. **Vytvořte nový repozitář na GitHub**
2. **Nahrajte soubory:**
   - Nahrajte `project.zip` do kořenového adresáře
   - Nahrajte `.github/workflows/deploy.yml`
   - Commit s názvem "Initial upload"

### 3. Spuštění GitHub Actions

**Možnost A: Automatické spuštění**
- Push do `main` branch spustí workflow automaticky

**Možnost B: Manuální spuštění**
- Jděte do "Actions" tab
- Vyberte "Deploy from ZIP" workflow
- Klikněte "Run workflow"
- Zadejte cestu k ZIP souboru (např. `project.zip`)

### 4. Workflow stages

1. **extract-and-build:**
   - Rozbalí ZIP soubor
   - Buildí frontend (React)
   - Připraví backend
   - Uloží artifacts

2. **deploy:**
   - Stáhne artifacts
   - Nasazuje na server (manuální nastavení)

### 5. Nastavení deploy

V `.github/workflows/deploy.yml` upravte deploy script:

```yaml
- name: Deploy to Server
  run: |
    echo "Deploying to server..."
    rsync -avz --delete frontend/dist/ user@server:/path/to/public_html/
    rsync -avz --delete backend/ user@server:/path/to/api/
```

### 6. GitHub Secrets

V Settings > Secrets and variables > Actions nastavte:
- `SSH_PRIVATE_KEY` - Váš SSH klíč pro server
- `SERVER_HOST` - IP adresa serveru
- `SERVER_USER` - Uživatelské jméno na serveru

## Výhody GitHub Actions

✅ **Gratis** - 2000 minut/měsíc zdarma
✅ **Automatické** - spustí se při push
✅ **Flexibilní** - manuální spuštění možné
✅ **Artifacts** - uložené build soubory
✅ **Logs** - detailní logy procesu

## Aktualizace

Pro aktualizaci:
1. Upravte kód lokálně
2. Zabalte nový ZIP
3. Nahrajte na GitHub
4. Spusťte workflow

## Troubleshooting

### Workflow selže při extract
- Zkontrolujte, že ZIP se jmenuje `project.zip`
- Zkontrolujte, že ZIP obsahuje správnou strukturu

### Build selže
- Zkontrolujte, že `package.json` soubory jsou správné
- Zkontrolujte GitHub Actions logs

### Deploy selže
- Zkontrolujte GitHub Secrets
- Zkontrolujte cestu k serveru v deploy scriptu

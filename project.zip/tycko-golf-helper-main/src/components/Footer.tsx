import { Facebook, Instagram, Mail, Phone } from "lucide-react";
const tyckoFooterLogo = "/lovable-uploads/d478a138-36cb-44ed-958c-c1f8468a2482.png";

export function Footer() {
  return (
    <footer className="mt-auto" style={{ backgroundColor: '#1A5948' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-white">
          {/* Logo */}
          <div>
            <img src={tyckoFooterLogo} alt="Týčko help" className="h-8 w-auto" />
          </div>

          {/* Adresa */}
          <div className="space-y-2 text-sm opacity-90">
            <p>Golferis.cz s.r.o.</p>
            <p>Brněnská 412/59</p>
            <p>Slavonín 783 01 Olomouc</p>
            <p>IČ: 04202970</p>
          </div>

          {/* Kontakty a sociální sítě */}
          <div className="space-y-3">
            <a 
              href="mailto:help@tycko.cz" 
              className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100 transition-opacity"
            >
              <Mail className="h-4 w-4" />
              help@tycko.cz
            </a>
            <a 
              href="tel:+420774177222" 
              className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100 transition-opacity"
            >
              <Phone className="h-4 w-4" />
              +420 774 177 222
            </a>
            <a 
              href="https://www.facebook.com/tycko.golf/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100 transition-opacity"
            >
              <Facebook className="h-4 w-4" />
              Facebook
            </a>
            <a 
              href="https://www.instagram.com/tycko.golf/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100 transition-opacity"
            >
              <Instagram className="h-4 w-4" />
              Instagram
            </a>
          </div>

          {/* Právní odkazy */}
          <div className="space-y-2">
            <a 
              href="#" 
              className="block text-sm opacity-90 hover:opacity-100 transition-opacity underline"
            >
              Zpracování osobních údajů
            </a>
            <a 
              href="#" 
              className="block text-sm opacity-90 hover:opacity-100 transition-opacity underline"
            >
              Všeobecné obchodní podmínky
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
import { Card } from "@/components/ui/card";
import { Question } from "@/data/faqData";
import { ChevronRight, Image } from "lucide-react";

interface QuestionCardProps {
  question: Question;
  onClick: () => void;
  isCompact?: boolean;
}

export function QuestionCard({ question, onClick, isCompact = false }: QuestionCardProps) {
  return (
    <Card 
      className="cursor-pointer transition-all duration-300 hover:shadow-lg border border-border bg-card group hover-scale animate-fade-in rounded-xl"
      onClick={onClick}
    >
      <div className={isCompact ? "p-4" : "p-6"}>
        <div className="flex items-start justify-between">
          <div className="flex-1 pr-2">
            <h3 className={`font-medium text-foreground group-hover:text-primary transition-colors leading-relaxed ${
              isCompact ? "text-sm" : "text-base"
            }`}>
              {question.title}
            </h3>
          </div>
          <ChevronRight className={`text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0 mt-0.5 ${
            isCompact ? "h-4 w-4" : "h-5 w-5"
          }`} />
        </div>
      </div>
    </Card>
  );
}
const tyckoLogo = "/lovable-uploads/ea40dd93-b95c-4d9e-967e-d86541013e8f.png";
import tyckoFullLogo from "@/assets/tycko-full-logo.svg";
import { Search, Menu, X, Trophy, Newspaper, Instagram, Facebook } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

interface HeaderProps {
  onSearchChange?: (query: string) => void;
  searchQuery?: string;
}

export function Header({ onSearchChange, searchQuery = "" }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="bg-header border-b border-border sticky top-0 z-50 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center cursor-pointer" onClick={() => navigate("/")}>
            <img src={tyckoLogo} alt="Týčko help" className="h-8 w-auto" />
          </div>

          {/* Desktop Search */}
          <div className="hidden lg:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5" style={{ color: '#268068' }} />
              <Input
                type="text"
                placeholder="Vyhledat..."
                value={searchQuery}
                onChange={(e) => onSearchChange?.(e.target.value)}
                className="pl-12 h-11 text-base bg-background border-border/40 rounded-lg transition-all"
                style={{ 
                  color: '#268068',
                  '--tw-placeholder-color': '#268068',
                  '--placeholder-opacity': '0.7'
                } as React.CSSProperties}
              />
            </div>
          </div>

          {/* Mobile Search Icon + Desktop Navigation */}
          <div className="flex items-center gap-2">
            {/* Mobile Search Icon */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden"
              onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
            >
              <Search className="h-5 w-5" />
            </Button>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-6">
              <a 
                href="https://www.instagram.com/tycko.golf/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="https://www.facebook.com/tycko.golf/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="https://blog.tycko.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-inter font-bold text-base text-muted-foreground hover:text-primary transition-colors flex items-center gap-2"
              >
                <Newspaper className="h-4 w-4" />
                Týčko blog
              </a>
              <a 
                href="http://tyckotour.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-inter font-bold text-base text-muted-foreground hover:text-primary transition-colors flex items-center gap-2"
              >
                <Trophy className="h-4 w-4" />
                Týčko Tour
              </a>
              <a 
                href="https://www.tycko.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <img src={tyckoFullLogo} alt="Týčko" className="h-6 w-auto" />
              </a>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        {isMobileSearchOpen && (
          <div className="lg:hidden py-4 border-t border-border animate-fade-in">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5" style={{ color: '#268068' }} />
              <Input
                type="text"
                placeholder="Vyhledat..."
                value={searchQuery}
                onChange={(e) => onSearchChange?.(e.target.value)}
                className="pl-12 h-11 text-base bg-background border-border/40 rounded-lg transition-all"
                style={{ 
                  color: '#268068',
                  '--tw-placeholder-color': '#268068',
                  '--placeholder-opacity': '0.7'
                } as React.CSSProperties}
                autoFocus
              />
            </div>
          </div>
        )}

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border animate-fade-in">
            <div className="flex flex-col gap-4">
              <a 
                href="https://www.instagram.com/tycko.golf/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-inter font-bold text-base text-muted-foreground hover:text-primary transition-colors flex items-center gap-3"
              >
                <Instagram className="h-5 w-5" />
                Instagram
              </a>
              <a 
                href="https://www.facebook.com/tycko.golf/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-inter font-bold text-base text-muted-foreground hover:text-primary transition-colors flex items-center gap-3"
              >
                <Facebook className="h-5 w-5" />
                Facebook
              </a>
              <a 
                href="https://blog.tycko.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-inter font-bold text-base text-muted-foreground hover:text-primary transition-colors flex items-center gap-3"
              >
                <Newspaper className="h-4 w-4" />
                Týčko blog
              </a>
              <a 
                href="http://tyckotour.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-inter font-bold text-base text-muted-foreground hover:text-primary transition-colors flex items-center gap-3"
              >
                <Trophy className="h-4 w-4" />
                Týčko Tour
              </a>
              <a 
                href="https://www.tycko.cz/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                <img src={tyckoFullLogo} alt="Týčko" className="h-6 w-auto" />
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
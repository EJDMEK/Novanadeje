import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Category } from "@/data/faqData";
import { ChevronRight, BookOpen, Zap, Target, Users, Shirt, MapPin } from "lucide-react";

const iconMap = {
  BookOpen,
  Zap,
  Target,
  Users,
  Shirt,
  MapPin
};

interface CategoryCardProps {
  category: Category;
  onClick: () => void;
}

export function CategoryCard({ category, onClick }: CategoryCardProps) {
  const IconComponent = iconMap[category.icon as keyof typeof iconMap];
  
  return (
    <Card 
      className="p-6 cursor-pointer transition-all duration-300 hover:shadow-lg border border-border bg-card group hover-scale animate-fade-in rounded-xl"
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-all duration-200">
              <IconComponent className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
              {category.name}
            </h3>
          </div>
          <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
            {category.description}
          </p>
          <div className="flex items-center justify-between">
            <Badge variant="secondary" className="text-xs">
              {category.questions.length} {category.questions.length === 1 ? 'otázka' : 
               category.questions.length < 5 ? 'otázky' : 'otázek'}
            </Badge>
          </div>
        </div>
        <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors ml-4" />
      </div>
    </Card>
  );
}
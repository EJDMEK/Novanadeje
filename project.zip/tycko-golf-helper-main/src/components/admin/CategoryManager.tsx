import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, BookOpen, Zap, Target, Users, Shirt, MapPin, Search } from "lucide-react";
import { api, Category } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

const availableIcons = [
  { name: "BookOpen", icon: BookOpen, label: "Kniha" },
  { name: "Zap", icon: Zap, label: "Blesk" },
  { name: "Target", icon: Target, label: "Terč" },
  { name: "Users", icon: Users, label: "Uživatelé" },
  { name: "Shirt", icon: Shirt, label: "Oblečení" },
  { name: "MapPin", icon: MapPin, label: "Mapa" }
];

export function CategoryManager() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    id: "",
    name: "",
    description: "",
    icon: "BookOpen"
  });

  // Načtení kategorií
  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      setLoading(true);
      const data = await api.getCategories();
      setCategories(data);
    } catch (error) {
      toast({
        title: "Chyba",
        description: "Nepodařilo se načíst kategorie",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Filtrování kategorií
  const filteredCategories = categories.filter(category => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      category.name.toLowerCase().includes(query) ||
      category.description.toLowerCase().includes(query)
    );
  });

  const handleOpenDialog = (category?: Category) => {
    if (category) {
      setEditingCategory(category);
      setFormData({
        id: category.id,
        name: category.name,
        description: category.description,
        icon: category.icon
      });
    } else {
      setEditingCategory(null);
      setFormData({
        id: "",
        name: "",
        description: "",
        icon: "BookOpen"
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) {
      toast({
        title: "Chyba",
        description: "Název kategorie je povinný",
        variant: "destructive",
      });
      return;
    }

    try {
      setSaving(true);
      
      if (editingCategory) {
        // Aktualizace existující kategorie
        await api.updateCategory({
          id: formData.id,
          name: formData.name,
          description: formData.description,
          icon: formData.icon
        });
        toast({
          title: "Úspěch",
          description: "Kategorie byla aktualizována",
        });
      } else {
        // Vytvoření nové kategorie
        const newId = formData.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
        await api.createCategory({
          id: newId,
          name: formData.name,
          description: formData.description,
          icon: formData.icon
        });
        toast({
          title: "Úspěch",
          description: "Kategorie byla vytvořena",
        });
      }
      
      setIsDialogOpen(false);
      loadCategories(); // Znovu načíst kategorie
    } catch (error) {
      toast({
        title: "Chyba",
        description: error instanceof Error ? error.message : "Nepodařilo se uložit kategorii",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (categoryId: string) => {
    if (!confirm("Opravdu chcete smazat tuto kategorii?")) {
      return;
    }

    try {
      await api.deleteCategory(categoryId);
      toast({
        title: "Úspěch",
        description: "Kategorie byla smazána",
      });
      loadCategories(); // Znovu načíst kategorie
    } catch (error) {
      toast({
        title: "Chyba",
        description: error instanceof Error ? error.message : "Nepodařilo se smazat kategorii",
        variant: "destructive",
      });
    }
  };

  const IconComponent = ({ iconName }: { iconName: string }) => {
    const iconData = availableIcons.find(i => i.name === iconName);
    if (!iconData) return <BookOpen className="h-5 w-5" />;
    const Icon = iconData.icon;
    return <Icon className="h-5 w-5" />;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Načítání kategorií...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Existující kategorie</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Přidat kategorii
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingCategory ? "Upravit kategorii" : "Přidat kategorii"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Název kategorie</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Např. Pravidla golfu"
                />
              </div>
              <div>
                <Label htmlFor="description">Popis</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Krátký popis kategorie"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="icon">Ikona</Label>
                <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {availableIcons.map((icon) => (
                      <SelectItem key={icon.name} value={icon.name}>
                        <div className="flex items-center gap-2">
                          <icon.icon className="h-4 w-4" />
                          {icon.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleSave} className="w-full" disabled={saving}>
                {saving ? "Ukládání..." : editingCategory ? "Uložit změny" : "Přidat kategorii"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search input */}
      <div className="relative mb-4">
        <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Hledat kategorie..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {searchQuery && (
        <div className="text-sm text-muted-foreground mb-4">
          Nalezeno: {filteredCategories.length} {filteredCategories.length === 1 ? 'kategorie' : filteredCategories.length < 5 ? 'kategorie' : 'kategorií'}
        </div>
      )}

      <div className="grid gap-4">
        {filteredCategories.map((category) => (
          <Card key={category.id}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <IconComponent iconName={category.icon} />
                  <div>
                    <CardTitle className="text-base">{category.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      ID: {category.id}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleOpenDialog(category)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(category.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-muted-foreground">{category.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCategories.length === 0 && !loading && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            {searchQuery ? "Žádné kategorie neodpovídají vyhledávání" : "Žádné kategorie nebyly nalezeny"}
          </p>
        </div>
      )}
    </div>
  );
}
import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Bold, Italic, Image, Link } from "lucide-react";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
}

export function RichTextEditor({ value, onChange }: RichTextEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const insertText = (before: string, after: string = "") => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    
    onChange(newText);
    
    // Restore cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + before.length, end + before.length);
    }, 0);
  };

  const insertBold = () => insertText("**", "**");
  const insertItalic = () => insertText("*", "*");
  const insertImage = () => {
    const url = prompt("Zadejte URL obrázku:");
    if (url) {
      insertText(`![Popis obrázku](${url})`);
    }
  };
  const insertLink = () => {
    const url = prompt("Zadejte URL odkazu:");
    if (url) {
      const text = prompt("Zadejte text odkazu:") || url;
      insertText(`[${text}](${url})`);
    }
  };

  return (
    <div className="border rounded-lg">
      <div className="border-b p-2 flex gap-2">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={insertBold}
          title="Tučné písmo"
        >
          <Bold className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={insertItalic}
          title="Kurzíva"
        >
          <Italic className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={insertImage}
          title="Vložit obrázek"
        >
          <Image className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={insertLink}
          title="Vložit odkaz"
        >
          <Link className="h-4 w-4" />
        </Button>
      </div>
      <Textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Napište odpověď na otázku... Můžete použít Markdown formátování."
        className="border-0 min-h-[200px] resize-none focus-visible:ring-0"
        rows={8}
      />
      <div className="p-2 text-xs text-muted-foreground border-t bg-muted/20">
        <p>Podporované formátování:</p>
        <p>**tučné** *kurzíva* ![obrázek](url) [odkaz](url)</p>
      </div>
    </div>
  );
}
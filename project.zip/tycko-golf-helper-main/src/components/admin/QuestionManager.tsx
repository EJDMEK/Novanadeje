import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, Image, Search, Filter } from "lucide-react";
import { RichTextEditor } from "./RichTextEditor";
import { api, Question, Category } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function QuestionManager() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    id: "",
    title: "",
    content: "",
    keywords: "",
    categoryId: "",
    image: "",
    isFeatured: false
  });

  // Načtení dat
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [questionsData, categoriesData] = await Promise.all([
        api.getQuestions(),
        api.getCategories()
      ]);
      setQuestions(questionsData);
      setCategories(categoriesData);
    } catch (error) {
      toast({
        title: "Chyba",
        description: "Nepodařilo se načíst data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Filtrování otázek
  const filteredQuestions = questions.filter(question => {
    const matchesSearch = !searchQuery.trim() || 
      question.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      question.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (question.keywords && question.keywords.toLowerCase().includes(searchQuery.toLowerCase())) ||
      getCategoryName(question.categoryId).toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = filterCategory === "all" || question.categoryId === filterCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handleOpenDialog = (question?: Question) => {
    if (question) {
      setEditingQuestion(question);
      setFormData({
        id: question.id,
        title: question.title,
        content: question.content,
        keywords: question.keywords || "",
        categoryId: question.categoryId,
        image: question.image || "",
        isFeatured: question.isFeatured || false
      });
    } else {
      setEditingQuestion(null);
      setFormData({
        id: "",
        title: "",
        content: "",
        keywords: "",
        categoryId: categories[0]?.id || "",
        image: "",
        isFeatured: false
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title.trim() || !formData.content.trim() || !formData.categoryId) {
      toast({
        title: "Chyba",
        description: "Nadpis, obsah a kategorie jsou povinné",
        variant: "destructive",
      });
      return;
    }

    try {
      setSaving(true);
      
      if (editingQuestion) {
        // Aktualizace existující otázky
        await api.updateQuestion({
          id: formData.id,
          title: formData.title,
          content: formData.content,
          image: formData.image,
          categoryId: formData.categoryId,
          keywords: formData.keywords,
          isFeatured: formData.isFeatured
        });
        toast({
          title: "Úspěch",
          description: "Otázka byla aktualizována",
        });
      } else {
        // Vytvoření nové otázky
        const newId = formData.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
        await api.createQuestion({
          id: newId,
          title: formData.title,
          content: formData.content,
          image: formData.image,
          categoryId: formData.categoryId,
          keywords: formData.keywords,
          isFeatured: formData.isFeatured
        });
        toast({
          title: "Úspěch",
          description: "Otázka byla vytvořena",
        });
      }
      
      setIsDialogOpen(false);
      loadData(); // Znovu načíst data
    } catch (error) {
      toast({
        title: "Chyba",
        description: error instanceof Error ? error.message : "Nepodařilo se uložit otázku",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (questionId: string) => {
    if (!confirm("Opravdu chcete smazat tuto otázku?")) {
      return;
    }

    try {
      await api.deleteQuestion(questionId);
      toast({
        title: "Úspěch",
        description: "Otázka byla smazána",
      });
      loadData(); // Znovu načíst data
    } catch (error) {
      toast({
        title: "Chyba",
        description: error instanceof Error ? error.message : "Nepodařilo se smazat otázku",
        variant: "destructive",
      });
    }
  };

  const getCategoryName = (categoryId: string) => {
    return categories.find(c => c.id === categoryId)?.name || "Neznámá kategorie";
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Načítání otázek...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Existující otázky</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()} disabled={categories.length === 0}>
              <Plus className="h-4 w-4 mr-2" />
              Přidat otázku
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingQuestion ? "Upravit otázku" : "Přidat otázku"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Nadpis otázky</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Např. Co je golfový handicap?"
                />
              </div>
              
              <div>
                <Label htmlFor="category">Kategorie</Label>
                <Select value={formData.categoryId} onValueChange={(value) => setFormData({ ...formData, categoryId: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="keywords">Klíčová slova (oddělená čárkou)</Label>
                <Input
                  id="keywords"
                  value={formData.keywords}
                  onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                  placeholder="handicap, golf, pravidla"
                />
              </div>

              <div>
                <Label htmlFor="image">URL obrázku</Label>
                <Input
                  id="image"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div>
                <Label>Obsah odpovědi</Label>
                <div className="mt-2">
                  <RichTextEditor
                    value={formData.content}
                    onChange={(value) => setFormData({ ...formData, content: value })}
                  />
                </div>
              </div>

              <Button onClick={handleSave} className="w-full" disabled={saving}>
                {saving ? "Ukládání..." : editingQuestion ? "Uložit změny" : "Přidat otázku"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and filter controls */}
      <div className="flex gap-4 mb-4">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Hledat otázky..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-48">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <SelectValue />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Všechny kategorie</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {(searchQuery || filterCategory !== "all") && (
        <div className="text-sm text-muted-foreground mb-4">
          Nalezeno: {filteredQuestions.length} {filteredQuestions.length === 1 ? 'otázka' : filteredQuestions.length < 5 ? 'otázky' : 'otázek'}
        </div>
      )}

      <div className="grid gap-4">
        {filteredQuestions.map((question) => (
          <Card key={question.id}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-base line-clamp-2">{question.title}</CardTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-sm text-muted-foreground">
                      {getCategoryName(question.categoryId)}
                    </p>
                    {question.isFeatured && (
                      <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                        Nejčastější
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2 ml-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleOpenDialog(question)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(question.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-muted-foreground line-clamp-2">
                {question.content}
              </p>
              {question.image && (
                <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                  <Image className="h-3 w-3" />
                  Obsahuje obrázek
                </div>
              )}
              {question.keywords && (
                <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                  Klíčová slova: {question.keywords}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredQuestions.length === 0 && !loading && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            {searchQuery || filterCategory !== "all" 
              ? "Žádné otázky neodpovídají vyhledávání" 
              : "Žádné otázky nebyly nalezeny"}
          </p>
        </div>
      )}
    </div>
  );
}
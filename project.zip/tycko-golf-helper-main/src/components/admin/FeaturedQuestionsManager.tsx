import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Star, StarOff, Search, Filter } from "lucide-react";
import { api, Question, Category } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function FeaturedQuestionsManager() {
  const [featuredQuestions, setFeaturedQuestions] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  // Načtení dat
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [questionsData, categoriesData] = await Promise.all([
        api.getQuestions(),
        api.getCategories()
      ]);
      setQuestions(questionsData);
      setCategories(categoriesData);
      
      // Nastavit aktuální featured otázky
      const featured = questionsData.filter(q => q.isFeatured).map(q => q.id);
      setFeaturedQuestions(featured);
    } catch (error) {
      toast({
        title: "Chyba",
        description: "Nepodařilo se načíst data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Filtrování otázek
  const filteredQuestions = questions.filter(question => {
    const matchesSearch = !searchQuery.trim() || 
      question.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      question.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (question.keywords && question.keywords.toLowerCase().includes(searchQuery.toLowerCase())) ||
      getCategoryName(question.categoryId).toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = filterCategory === "all" || question.categoryId === filterCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handleToggleFeatured = (questionId: string) => {
    setFeaturedQuestions(prev => 
      prev.includes(questionId)
        ? prev.filter(id => id !== questionId)
        : [...prev, questionId]
    );
  };

  const getCategoryName = (categoryId: string) => {
    return categories.find(c => c.id === categoryId)?.name || "Neznámá kategorie";
  };

  const saveFeaturedQuestions = async () => {
    try {
      setSaving(true);
      await api.updateFeaturedQuestions(featuredQuestions);
      toast({
        title: "Úspěch",
        description: "Nejčastější otázky byly aktualizovány",
      });
      loadData(); // Znovu načíst data pro aktualizaci UI
    } catch (error) {
      toast({
        title: "Chyba",
        description: error instanceof Error ? error.message : "Nepodařilo se uložit nejčastější otázky",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Načítání otázek...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Nejčastější otázky</h3>
        <Button onClick={saveFeaturedQuestions} disabled={saving}>
          {saving ? "Ukládání..." : "Uložit změny"}
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          <Star className="h-4 w-4 inline mr-2" />
          Zaškrtnuté otázky se zobrazí jako nejčastější na hlavní stránce.
        </p>
      </div>

      {/* Search and filter controls */}
      <div className="flex gap-4 mb-4">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Hledat otázky..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-48">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <SelectValue />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Všechny kategorie</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {(searchQuery || filterCategory !== "all") && (
        <div className="text-sm text-muted-foreground mb-4">
          Nalezeno: {filteredQuestions.length} {filteredQuestions.length === 1 ? 'otázka' : filteredQuestions.length < 5 ? 'otázky' : 'otázek'}
        </div>
      )}

      <div className="grid gap-4">
        {filteredQuestions.map((question) => (
          <Card key={question.id} className={featuredQuestions.includes(question.id) ? "border-yellow-200 bg-yellow-50" : ""}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Checkbox
                    checked={featuredQuestions.includes(question.id)}
                    onCheckedChange={() => handleToggleFeatured(question.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <CardTitle className="text-base line-clamp-2">{question.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-sm text-muted-foreground">
                        {getCategoryName(question.categoryId)}
                      </p>
                      {featuredQuestions.includes(question.id) && (
                        <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded flex items-center gap-1">
                          <Star className="h-3 w-3" />
                          Nejčastější
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-muted-foreground line-clamp-2">
                {question.content}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredQuestions.length === 0 && !loading && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            {searchQuery || filterCategory !== "all" 
              ? "Žádné otázky neodpovídají vyhledávání" 
              : "Žádné otázky nebyly nalezeny"}
          </p>
        </div>
      )}

      {featuredQuestions.length > 0 && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-sm text-green-800">
            <Star className="h-4 w-4 inline mr-2" />
            Aktuálně máte {featuredQuestions.length} {featuredQuestions.length === 1 ? 'nejčastější otázku' : featuredQuestions.length < 5 ? 'nejčastější otázky' : 'nejčastějších otázek'}.
          </p>
        </div>
      )}
    </div>
  );
}
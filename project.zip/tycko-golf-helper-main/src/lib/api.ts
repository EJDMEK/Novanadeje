const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export interface Question {
  id: string;
  title: string;
  content: string;
  image: string;
  categoryId: string;
  keywords?: string;
  isFeatured?: boolean;
  createdAt?: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
}

class ApiClient {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Neznámá chyba' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  // Kategorie
  async getCategories(): Promise<Category[]> {
    return this.request<Category[]>('/categories');
  }

  async createCategory(category: Omit<Category, 'id'> & { id?: string }): Promise<Category> {
    return this.request<Category>('/admin/categories', {
      method: 'POST',
      body: JSON.stringify(category),
    });
  }

  async updateCategory(category: Category): Promise<Category> {
    return this.request<Category>('/admin/categories', {
      method: 'POST',
      body: JSON.stringify(category),
    });
  }

  async deleteCategory(id: string): Promise<{ message: string }> {
    return this.request<{ message: string }>(`/admin/categories/${id}`, {
      method: 'DELETE',
    });
  }

  // Otázky
  async getQuestions(params?: {
    categoryId?: string;
    search?: string;
    featured?: boolean;
  }): Promise<Question[]> {
    const searchParams = new URLSearchParams();
    if (params?.categoryId) searchParams.append('categoryId', params.categoryId);
    if (params?.search) searchParams.append('search', params.search);
    if (params?.featured) searchParams.append('featured', 'true');

    const query = searchParams.toString();
    return this.request<Question[]>(`/questions${query ? `?${query}` : ''}`);
  }

  async getQuestion(id: string): Promise<Question> {
    return this.request<Question>(`/questions/${id}`);
  }

  async createQuestion(question: Omit<Question, 'id'> & { id?: string }): Promise<Question> {
    return this.request<Question>('/admin/questions', {
      method: 'POST',
      body: JSON.stringify(question),
    });
  }

  async updateQuestion(question: Question): Promise<Question> {
    return this.request<Question>('/admin/questions', {
      method: 'POST',
      body: JSON.stringify(question),
    });
  }

  async deleteQuestion(id: string): Promise<{ message: string }> {
    return this.request<{ message: string }>(`/admin/questions/${id}`, {
      method: 'DELETE',
    });
  }

  // Featured otázky
  async updateFeaturedQuestions(questionIds: string[]): Promise<{ message: string }> {
    return this.request<{ message: string }>('/admin/featured', {
      method: 'POST',
      body: JSON.stringify({ questionIds }),
    });
  }

  // Health check
  async healthCheck(): Promise<{ status: string; timestamp: string }> {
    return this.request<{ status: string; timestamp: string }>('/health');
  }
}

export const api = new ApiClient();

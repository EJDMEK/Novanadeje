export interface Question {
  id: string;
  title: string;
  content: string;
  image: string;
  categoryId: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  questions: Question[];
}

// Sample FAQ data for golf help
export const categories: Category[] = [
  {
    id: "pravidla-golfu",
    name: "Pravidla golfu",
    description: "Základní pravidla a předpisy ve golfu",
    icon: "BookOpen",
    questions: [
      {
        id: "handicap",
        title: "Co je golfový handicap a jak se počítá?",
        content: "Golfový handicap je číselné vyjádření hráčovy schopnosti. Představuje počet úderů nad par kurzu, které hráč v průměru potřebuje k dokončení 18 jamek. Handicap se počítá z posledních 20 kol, přičemž se bere průměr z nejlepších 8 výsledků. Čím nižší handicap, tím lepší hráč. Handicap 0 znamená, že hráč hraje na úrovni par kurzu.",
        image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?w=800&h=400&fit=crop",
        categoryId: "pravidla-golfu"
      },
      {
        id: "par",
        title: "Co znamená PAR u golfové jamky?",
        content: "PAR představuje počet úderů, který by měl zkušený hráč potřebovat k dokončení jamky za normálních podmínek. Par 3 znamená krátkou jamku (obvykle do 230m), par 4 střední jamku (230-430m) a par 5 dlouhou jamku (přes 430m). Celkový par 18jamkového kurzu je obvykle mezi 70-72 údery.",
        image: "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=800&h=400&fit=crop",
        categoryId: "pravidla-golfu"
      }
    ]
  },
  {
    id: "golfove-hole",
    name: "Golfové hole",
    description: "Výběr a použití golfových holí",
    icon: "Zap",
    questions: [
      {
        id: "typy-holi",
        title: "Jaké typy golfových holí existují?",
        content: "Golfové hole se dělí do několik hlavních kategorií: Drivery (nejdelší hole pro odpaly z tee), železné hole (numbered irons 3-9 pro různé vzdálenosti), wedge (pro krátké údery a výpady z bunkerů), puttery (pro golfování na greenu). Každá hůl má specifické použití podle vzdálenosti a typu úderu.",
        image: "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?w=800&h=400&fit=crop",
        categoryId: "golfove-hole"
      },
      {
        id: "vybor-holi",
        title: "Jak vybrat správnou hůl pro určitou vzdálenost?",
        content: "Výběr hole závisí na vzdálenosti k jamce, podmínkách kurzu a vašich schopnostech. Driver se používá pro nejdelší odpaly (200-300m+), železné hole 3-9 pro střední vzdálenosti (100-180m), wedge pro krátké údery (do 100m) a putter pouze na greenu. Začátečníci by měli začít s hybridními holemi, které jsou více odpouštějící.",
        image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=400&fit=crop",
        categoryId: "golfove-hole"
      }
    ]
  },
  {
    id: "technika-hry",
    name: "Technika hry",
    description: "Základní techniky a postupy ve golfu",
    icon: "Target",
    questions: [
      {
        id: "grip",
        title: "Jak správně držet golfovou hůl?",
        content: "Správný grip je základem úspěšného golfu. Levá ruka (pro praváky) se umístí na hůl tak, aby byly vidět 2-3 klouby. Pravá ruka se umístí pod levou, přičemž palec levé ruky se vejde do dlaně pravé. Existují tři základní typy gripu: overlap (nejběžnější), interlock a baseball grip. Pressure gripu má být jako když držíte živé ptáče - pevně, ale ne příliš.",
        image: "https://images.unsplash.com/photo-1626947086168-9b105fc022b6?w=800&h=400&fit=crop",
        categoryId: "technika-hry"
      },
      {
        id: "stance",
        title: "Jaký je správný postoj při úderu?",
        content: "Správný postoj (stance) je klíčový pro přesnost a sílu úderu. Nohy by měly být na šířku ramen, váha rovnoměrně rozložená. Míček se umisťuje různě podle hole - pro driver doprostřed až k levé noze, pro krátké hole více doprostřed. Záda rovná, mírný předklon v bocích, kolena mírně pokrčená. Ruce visí přirozeně pod rameny.",
        image: "https://images.unsplash.com/photo-1592319611550-57cb9261926a?w=800&h=400&fit=crop",
        categoryId: "technika-hry"
      }
    ]
  },
  {
    id: "etiketa",
    name: "Etiketa na hřišti",
    description: "Pravidla chování a etika na golfu",
    icon: "Users",
    questions: [
      {
        id: "rychlost-hry",
        title: "Jak udržovat správnou rychlost hry?",
        content: "Rychlost hry je klíčová pro příjemný zážitek všech hráčů. Připravte se na svůj úder již během chůze k míčku. Nehledejte míček déle než 3 minuty. Nechte rychlejší skupiny předběhnout. Na tee si připravte míček už během čekání. Na greenu si označte míček a připravte se na putting. Respektujte časy startu a dostavte se včas.",
        image: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800&h=400&fit=crop",
        categoryId: "etiketa"
      },
      {
        id: "bezpecnost",
        title: "Jaká jsou bezpečnostní pravidla na golfu?",
        content: "Bezpečnost má vždy prioritu. Nikdy nehrát, dokud nejsou všichni hráči v bezpečné vzdálenosti. Křičet 'FORE!' pokud míček letí směrem k jiným hráčům. Při swingu si dát pozor na ostatní hráče v okolí. Neházet hole a neprojevovat agresivitu. Na driving range dodržovat směr hry. Při bouřce okamžitě opustit hřiště.",
        image: "https://images.unsplash.com/photo-1535905557558-afc4877cdf3f?w=800&h=400&fit=crop",
        categoryId: "etiketa"
      }
    ]
  },
  {
    id: "vystroj",
    name: "Výstroj a vybavení",
    description: "Golfové vybavení a oblečení",
    icon: "Shirt",
    questions: [
      {
        id: "zakladni-vystroj",
        title: "Jaké základní vybavení potřebuji na golf?",
        content: "Základní golfové vybavení zahrnuje: sadu golfových holí (driver, železné hole 5-9, wedge, putter), golfové míčky, tees, rukavici (obvykle pouze na nedominantní ruku), golfové boty s nopy, golfový bag pro přenos holí. Doporučuje se také pitch fork na opravu greenu, mírkolitro na míčky a ručník na čištění holí.",
        image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=400&fit=crop",
        categoryId: "vystroj"
      },
      {
        id: "dress-code",
        title: "Jaký je dress code na golfových hřištích?",
        content: "Dress code se liší podle hřiště, ale obecně platí: košile s límečkem (polo shirt), dlouhé kalhoty nebo golfové kraťasy po kolena, golfové boty. Většina hřišť zakazuje: tričko bez límečka, rifle, sportovní kraťasy, tenisky. Pro ženy: slušivé golfové oblečení, sukně/kraťasy přiměřené délky. Vždy si ověřte pravidla konkrétního hřiště předem.",
        image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=400&fit=crop",
        categoryId: "vystroj"
      }
    ]
  },
  {
    id: "hriste",
    name: "Golfová hřiště",
    description: "Informace o golfových hřištích a jejich částech",
    icon: "MapPin",
    questions: [
      {
        id: "casti-hriste",
        title: "Jaké jsou hlavní části golfového hřiště?",
        content: "Golfové hřiště se skládá z několika klíčových částí: Tee box (místo pro odpal), fairway (střižený trávník mezi tee a greenem), rough (vyšší tráva po stranách fairway), hazardy (vodní překážky, bunkery), green (velmi krátce střižená plocha kolem jamky). Každá část má svá specifická pravidla a strategii hry.",
        image: "https://images.unsplash.com/photo-1551524164-6cf2ac58e513?w=800&h=400&fit=crop",
        categoryId: "hriste"
      },
      {
        id: "slope-rating",
        title: "Co znamená Slope Rating a Course Rating?",
        content: "Course Rating vyjadřuje obtížnost hřiště pro scratch golfistu (handicap 0). Slope Rating udává, jak moc se obtížnost zvyšuje pro hráče s vyšším handicapem oproti scratch golfistovi. Slope se pohybuje od 55 (nejlehčí) do 155 (nejtěžší), standard je 113. Tyto hodnoty se používají pro výpočet hraného handicapu na daném hřišti.",
        image: "https://images.unsplash.com/photo-1586022293617-3bdb646f1b46?w=800&h=400&fit=crop",
        categoryId: "hriste"
      }
    ]
  }
];

export function getAllQuestions(): Question[] {
  return categories.flatMap(category => category.questions);
}

export function searchQuestions(query: string): Question[] {
  if (!query.trim()) return getAllQuestions();
  
  const searchTerm = query.toLowerCase();
  return getAllQuestions().filter(question =>
    question.title.toLowerCase().includes(searchTerm) ||
    question.content.toLowerCase().includes(searchTerm)
  );
}
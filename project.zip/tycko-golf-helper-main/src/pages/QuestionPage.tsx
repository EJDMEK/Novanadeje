import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getAllQuestions, categories, searchQuestions } from "@/data/faqData";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { QuestionCard } from "@/components/QuestionCard";

export default function QuestionPage() {
  const { questionId } = useParams<{ questionId: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const question = getAllQuestions().find(q => q.id === questionId);
  const showSearchResults = searchQuery.trim().length > 0;
  const filteredQuestions = showSearchResults ? searchQuestions(searchQuery) : [];

  if (!question) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header onSearchChange={setSearchQuery} searchQuery={searchQuery} />
        <div className="max-w-4xl mx-auto px-4 py-8 text-center flex-1">
          <h1 className="text-2xl font-bold text-foreground mb-4">Otázka nenalezena</h1>
          <Button onClick={() => navigate("/")} variant="default">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zpět na hlavní stránku
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const category = categories.find(c => c.id === question.categoryId);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header onSearchChange={setSearchQuery} searchQuery={searchQuery} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1">
        {/* Search results or question content */}
        {showSearchResults ? (
          <div>
            {filteredQuestions.length > 0 ? (
              <>
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-foreground mb-2">
                    Výsledky vyhledávání
                  </h2>
                  <p className="text-muted-foreground">
                    Nalezeno {filteredQuestions.length} {
                      filteredQuestions.length === 1 ? "výsledek" : 
                      filteredQuestions.length < 5 ? "výsledky" : "výsledků"
                    } pro "{searchQuery}"
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredQuestions.map((question) => (
                    <QuestionCard
                      key={question.id}
                      question={question}
                      onClick={() => navigate(`/otazka/${question.id}`)}
                      isCompact={true}
                    />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-semibold text-foreground mb-4">
                  Žádné výsledky pro "{searchQuery}"
                </h2>
                <p className="text-muted-foreground text-sm">
                  Zkuste jiná klíčová slova nebo procházejte kategorie.
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <div className="mb-6 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          <Button 
            variant="default" 
            onClick={() => navigate("/")}
            className="bg-primary hover:bg-primary/90 text-white shadow-md hover:shadow-lg transition-all duration-200 hover-scale"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Hlavní stránka
          </Button>
          <span>/</span>
          {category && (
            <>
              <Button 
                variant="ghost"
                onClick={() => navigate(`/kategorie/${category.id}`)}
                className="text-muted-foreground hover:text-primary -mx-2"
              >
                {category.name}
              </Button>
              <span>/</span>
            </>
          )}
          <span className="text-foreground font-medium">Otázka</span>
        </div>

        {/* Question content */}
        <Card className="border border-border bg-card rounded-xl">
          <div className="p-8">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-6 leading-tight">
              {question.title}
            </h1>
            
            <div className="prose prose-gray max-w-none">
              <p className="text-foreground leading-relaxed text-base md:text-lg">
                {question.content}
              </p>
            </div>

            {/* Optional image as supporting content */}
            {question.image && (
              <div className="mt-6">
                <img
                  src={question.image}
                  alt={`Obrázek k otázce: ${question.title}`}
                  className="w-full max-w-md mx-auto rounded-xl border border-border shadow-sm"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />
              </div>
            )}

            {/* Back button */}
            <div className="mt-8 pt-6 border-t border-border">
              <Button 
                onClick={() => navigate(-1)}
                variant="default"
                className="bg-primary hover:bg-primary/90 text-white shadow-md hover:shadow-lg transition-all duration-200 hover-scale"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Zpět
              </Button>
            </div>
          </div>
        </Card>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
}
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CategoryCard } from "@/components/CategoryCard";
import { QuestionCard } from "@/components/QuestionCard";
import { categories, searchQuestions } from "@/data/faqData";

const Index = () => {
  // Force refresh after GitHub sync
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredQuestions = searchQuestions(searchQuery);
  const showSearchResults = searchQuery.trim().length > 0;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header onSearchChange={setSearchQuery} searchQuery={searchQuery} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1">
        {/* Search results or categories */}
        {showSearchResults ? (
          <div>
            {filteredQuestions.length > 0 ? (
              <>
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-foreground mb-2">
                    Výsledky vyhledávání
                  </h2>
                  <p className="text-muted-foreground">
                    Nalezeno {filteredQuestions.length} {
                      filteredQuestions.length === 1 ? "výsledek" : 
                      filteredQuestions.length < 5 ? "výsledky" : "výsledků"
                    } pro "{searchQuery}"
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredQuestions.map((question) => (
                    <QuestionCard
                      key={question.id}
                      question={question}
                      onClick={() => navigate(`/otazka/${question.id}`)}
                      isCompact={true}
                    />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-semibold text-foreground mb-4">
                  Žádné výsledky pro "{searchQuery}"
                </h2>
                <p className="text-muted-foreground text-sm">
                  Zkuste jiná klíčová slova nebo procházejte kategorie níže.
                </p>
              </div>
            )}
          </div>
        ) : (
          <div>
            {/* Nejčastější otázky */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Nejčastější otázky
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                {[
                  { id: "handicap", title: "Co je golfový handicap?", category: "Pravidla" },
                  { id: "par", title: "Co znamená PAR u jamky?", category: "Pravidla" },
                  { id: "typy-holi", title: "Jaké typy holí existují?", category: "Hole" }
                ].map((faq) => (
                  <div 
                    key={faq.id} 
                    className="p-4 bg-card border border-border rounded-xl cursor-pointer hover-scale animate-fade-in transition-all duration-300 hover:shadow-md group"
                    onClick={() => navigate(`/otazka/${faq.id}`)}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-medium text-primary/80 bg-primary/10 px-2 py-1 rounded-lg">
                        {faq.category}
                      </span>
                    </div>
                    <h3 className="font-medium text-sm text-foreground group-hover:text-primary transition-colors">
                      {faq.title}
                    </h3>
                  </div>
                ))}
              </div>
            </div>

            {/* Kategorie nápovědy */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Kategorie nápovědy
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((category) => (
                <CategoryCard
                  key={category.id}
                  category={category}
                  onClick={() => navigate(`/kategorie/${category.id}`)}
                />
              ))}
            </div>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { categories, searchQuestions } from "@/data/faqData";
import { QuestionCard } from "@/components/QuestionCard";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BookOpen, Zap, Target, Users, Shirt, MapPin } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const iconMap = {
  BookOpen,
  Zap,
  Target,
  Users,
  Shirt,
  MapPin
};

export default function CategoryPage() {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const category = categories.find(c => c.id === categoryId);
  const showSearchResults = searchQuery.trim().length > 0;
  const filteredQuestions = showSearchResults ? searchQuestions(searchQuery) : [];

  if (!category) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header onSearchChange={setSearchQuery} searchQuery={searchQuery} />
        <div className="max-w-4xl mx-auto px-4 py-8 text-center flex-1">
          <h1 className="text-2xl font-bold text-foreground mb-4">Kategorie nenalezena</h1>
          <Button onClick={() => navigate("/")} variant="default">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Zpět na hlavní stránku
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header onSearchChange={setSearchQuery} searchQuery={searchQuery} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1">
        {/* Search results or category content */}
        {showSearchResults ? (
          <div>
            {filteredQuestions.length > 0 ? (
              <>
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-foreground mb-2">
                    Výsledky vyhledávání
                  </h2>
                  <p className="text-muted-foreground">
                    Nalezeno {filteredQuestions.length} {
                      filteredQuestions.length === 1 ? "výsledek" : 
                      filteredQuestions.length < 5 ? "výsledky" : "výsledků"
                    } pro "{searchQuery}"
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredQuestions.map((question) => (
                    <QuestionCard
                      key={question.id}
                      question={question}
                      onClick={() => navigate(`/otazka/${question.id}`)}
                      isCompact={true}
                    />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-semibold text-foreground mb-4">
                  Žádné výsledky pro "{searchQuery}"
                </h2>
                <p className="text-muted-foreground text-sm">
                  Zkuste jiná klíčová slova nebo procházejte kategorie.
                </p>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Breadcrumb */}
            <div className="mb-6">
              <Button 
                variant="default" 
                onClick={() => navigate("/")}
                className="bg-primary hover:bg-primary/90 text-white shadow-md hover:shadow-lg transition-all duration-200 hover-scale"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Zpět na hlavní stránku
              </Button>
            </div>

            {/* Category header */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-3 rounded-lg bg-primary/10 text-primary">
                  {(() => {
                    const IconComponent = iconMap[category.icon as keyof typeof iconMap];
                    return IconComponent ? <IconComponent className="h-8 w-8" /> : null;
                  })()}
                </div>
                <h1 className="text-3xl font-bold text-foreground">
                  {category.name}
                </h1>
              </div>
              <p className="text-muted-foreground text-lg">
                {category.description}
              </p>
            </div>

            {/* Questions grid */}
            {category.questions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.questions.map((question) => (
                  <QuestionCard
                    key={question.id}
                    question={question}
                    onClick={() => navigate(`/otazka/${question.id}`)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">
                  V této kategorii nejsou žádné otázky
                </p>
              </div>
            )}
          </>
        )}
      </main>
      
      <Footer />
    </div>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CategoryManager } from "@/components/admin/CategoryManager";
import { QuestionManager } from "@/components/admin/QuestionManager";
import { FeaturedQuestionsManager } from "@/components/admin/FeaturedQuestionsManager";
import { Settings, FileText, Star } from "lucide-react";

export default function AdminPage() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground mb-1">
          Administrace FAQ
        </h1>
        <p className="text-sm text-muted-foreground">
          Správa kategorií, otázek a obsahu nápovědy
        </p>
      </div>

      <Tabs defaultValue="categories" className="space-y-4">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="categories" className="flex items-center gap-2 text-xs">
            <Settings className="h-3 w-3" />
            Kategorie
          </TabsTrigger>
          <TabsTrigger value="questions" className="flex items-center gap-2 text-xs">
            <FileText className="h-3 w-3" />
            Otázky
          </TabsTrigger>
          <TabsTrigger value="featured" className="flex items-center gap-2 text-xs">
            <Star className="h-3 w-3" />
            Nejčastější
          </TabsTrigger>
        </TabsList>

        <TabsContent value="categories" className="mt-4">
          <div className="border border-border rounded-lg p-4">
            <h2 className="text-lg font-semibold text-foreground mb-4">Správa kategorií</h2>
            <CategoryManager />
          </div>
        </TabsContent>

        <TabsContent value="questions" className="mt-4">
          <div className="border border-border rounded-lg p-4">
            <h2 className="text-lg font-semibold text-foreground mb-4">Správa otázek</h2>
            <QuestionManager />
          </div>
        </TabsContent>

        <TabsContent value="featured" className="mt-4">
          <div className="border border-border rounded-lg p-4">
            <h2 className="text-lg font-semibold text-foreground mb-4">Nejčastější otázky</h2>
            <FeaturedQuestionsManager />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}